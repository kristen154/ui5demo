# @sap/cds-dk

The command line client and development toolkit for the [SAP Cloud Application Programming Model (CAP)](https://cap.cloud.sap).

See the [usage docs](https://cap.cloud.sap/docs/get-started/) for more.

## License
This package is provided under the terms of the [SAP Developer License Agreement](https://tools.hana.ondemand.com/developer-license.txt).
